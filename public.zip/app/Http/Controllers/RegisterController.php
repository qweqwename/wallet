<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class RegisterController extends Controller
{
    //

    public function index(Request $request){

        $password = Str::random(12);
        $user = User::create([
            'balance' => 1000,
            'password' => $password,
        ]);

        auth()->login($user);

        return redirect()->route('payment.transfer')->with('modal',
            (object)[
                'title' => 'Вы успешно зарегистрировались!',
                'content' => "Запишите Ваши данные для входа. Логин: {$user->id}. Пароль: {$password}",
            ]
        );
    }
}
