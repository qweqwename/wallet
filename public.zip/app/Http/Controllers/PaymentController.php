<?php

namespace App\Http\Controllers;

use App\Models\Payment;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class PaymentController extends Controller
{
    public function index()
    {
        //
    }

    public function history()
    {
        //
        return view('payment.history');
    }

    public function transfer(Request $request)
    {

        $dateS = Carbon::now()->subMonth(1);
        $dateE = Carbon::now()->startOfMonth();

        $transferLastMonth = Payment::where([
            ['created_at', '>=', $dateS],
            ['from', '=', \auth()->user()->id],
        ])->sum(DB::raw('amount + fee'));

        $getLastMonth = Payment::where([
            ['created_at', '>=', $dateS],
            ['to', '=', \auth()->user()->id],
        ])->sum(DB::raw('amount'));

        $stats = (object)[
            'transfer' => $transferLastMonth,
            'get' => $getLastMonth,
        ];

        $fee = Setting::all()->first()->fee;

        if($request->input('find_id_payment')){
            $payments = Payment::where('id', '=', $request->input('find_id_payment'))->where(function ($query) {
                $query->where('from', '=', Auth::user()->id)->orWhere('to', '=', Auth::user()->id);
            })->paginate(10);
        } else {
            $payments = Payment::where('from', '=', Auth::user()->id)->orWhere('to', '=', Auth::user()->id)->orderBy('id', 'desc')->paginate(25);
        }

        return view('payment.transfer', compact('fee', 'payments', 'stats'));
    }

    public function store(Request $request)
    {

        $amountTransfer = str_replace(',', '.', $request->amount ?? '');
        if(preg_match('/^-?[0-9]+(?:\.[0-9]{1,2})?/', $amountTransfer, $matches)){
            $amountTransfer = floatval($matches[0]);
        }

        $request->merge([
            'amount' => $amountTransfer,
        ]);

        $validated = validator($request->all(), [
            'id' => ['required', 'numeric'],
            'amount' => ['required', 'numeric', 'min:0.01', 'regex:/^-?[0-9]+(?:\.[0-9]{1,2})?$/'],
        ])->validate();


        DB::beginTransaction();
        $userTo = DB::table('users')->where('id', '=', $request->id)->get()->first();

        if($userTo != null){
            $userFrom = DB::table('users')->where('id', '=', Auth::user()->id)->get()->first();

            $settings = Setting::all()->first();
            $fee = $settings->fee;
            $feeTransfer = $amountTransfer / 100 * $fee;
            preg_match('/^-?[0-9]+(?:\.[0-9]{1,2})?/', $feeTransfer, $matches);
            $feeTransfer = floatval($matches[0]);

            if($userFrom->balance >= ($amountTransfer + $feeTransfer)){


                DB::table('users')->where('id', '=', Auth::user()->id)->decrement(
                    'balance', ($amountTransfer + $feeTransfer)
                );

                DB::table('users')->where('id', '=', $userTo->id)->increment(
                    'balance', $amountTransfer
                );

                DB::table('users')->where('id', '=', $settings->admin_id)->increment(
                    'balance', $feeTransfer
                );

                $date = Carbon::now();

                DB::table('payments')->insert([
                    'amount' => $request->amount,
                    'from' => Auth::user()->id,
                    'to' => $userTo->id,
                    'fee' => $feeTransfer,
                    'created_at' => $date,
                ]);
            } else {
                return redirect()->back()->withErrors('На Вашем счету недостаточно средств')->withInput();
            }
        } else {
            DB::rollBack();
            return redirect()->back()->withErrors('Пользователя с таким кошельком не существует')->withInput();
        }


        DB::commit();

        return redirect()->route('payment.transfer')->with('modal',
            (object)[
                'title' => 'Готово',
                'content' => 'Перевод успешно выполнен!',
            ]
        );

    }

    public function show($id)
    {
        //
        return view('payment.show');
    }

    public function replenish(Request $request)
    {
        //
        $payments = Payment::paginate(10);

        if($request->input('find_id_payment')){
            $payments = Payment::where('id', '=', $request->input('find_id_payment')->where(function ($query) {
                $query->where('from', '=', Auth::user()->id)->orWhere('to', '=', Auth::user()->id);
            }));
        } else {
            $payments = Payment::where('from', '=', Auth::user()->id)->orWhere('to', '=', Auth::user()->id)->orderBy('id', 'desc')->paginate(10);
        }
        return view('payment.replenish',compact( 'payments'));
    }

    public function replenish_store(Request $request)
    {
        $amountReplenish = str_replace(',', '.', $request->amount_replenish ?? '');
        if(preg_match('/^-?[0-9]+(?:\.[0-9]{1,2})?/', $amountReplenish, $matches)){
            $amountReplenish = floatval($matches[0]);
        }

        $request->merge([
            'amount_replenish' => $amountReplenish,
        ]);

        $validated = validator($request->all(), [
            'amount_replenish' => ['required', 'numeric', 'min:0.01', 'regex:/^-?[0-9]+(?:\.[0-9]{1,2})?$/'],
        ])->validate();

        DB::beginTransaction();
        DB::table('users')->where('id', '=', Auth::user()->id)->increment(
            'balance', ($amountReplenish)
        );

        DB::commit();

        return redirect()->route('payment.replenish')->with('modal',
            (object)[
                'title' => 'Готово',
                'content' => "Ваш счет пополнен на $amountReplenish рублей!",
            ]
        );
    }
}
