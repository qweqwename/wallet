@extends('layouts.base')
@section('title', 'Мой кошелек')
@section('content')
    <p class="h3">Главная страница</p>

    <a href="{{route('login')}}">Авторизация</a>
    <a href="{{route('register')}}">Регистрация</a>
@endsection
