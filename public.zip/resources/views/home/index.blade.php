{{--@extends('layouts.bootstrap')

@section('title', 'Мой кошелек')

@section('content')

@endsection--}}

@include('home.landing')
