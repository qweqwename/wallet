@extends('layouts.base')

@section('title', 'Пополнить счет')

@section('content')

    <div class="row row-cards">
        <div class="col-12 col-md-6 d-flex order-md-1  order-1">
            <div class="card w-100 active">
                <div class="card-header">
                    <div class="col">
                        <div class="card-title">
                            {{__('Пополнить счет')}}
                        </div>
                    </div>
                </div>
                <form method="POST" action="{{route('payment.replenish')}}">
                    @csrf
                    <div class="card-body">

                        @if($errors->any())
                            <div class="alert alert-danger small p-2">
                                <ul class="mb-0">
                                    @foreach($errors->all() as $message)
                                        <li>
                                            {{$message}}
                                        </li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif

                        <div class="mb-1 mt-2">
                            <label class="form-label required mb-3">{{__('На сколько рублей хотите пополнить счет?')}}</label>
                            <input autocomplete="off" type="text" class="form-control" name="amount_replenish" placeholder="100">
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="row align-items-center">
                            <button type="submit" class="btn btn-primary w-100">
                                Перейти к пополнению
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>



        <div class="col-12 col-md-5 d-flex order-md-2  order-3 d-none">
            <div class="card w-100">
                <div class="card-header">
                    <div class="col">
                        <div class="card-title">
                            {{__('Статистика за 30 дней')}}
                        </div>
                    </div>
                </div>
                <form action="">
                    <div class="card-body">
                    </div>
                </form>
            </div>
        </div>


        <div class="col-12 col-md-12 d-flex order-md-3  order-2 mb-4">
            <div class="card w-100">
                <div class="card-header">
                    <div class="col">
                        <div class="card-title">
                            {{__('История платежей')}}
                        </div>
                    </div>
                </div>
                @include('includes.history')
            </div>
        </div>

    </div>

@endsection
