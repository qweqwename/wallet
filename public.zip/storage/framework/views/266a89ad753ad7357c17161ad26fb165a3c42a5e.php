<div class="card-body border-bottom py-3">
    <div class="ms-auto text-muted">
        <?php echo e(__('Поиск по ID')); ?>:
        <div class="ms-2 d-inline-block">
            <form action="">

                <div class="row g-2">
                    <div class="col">
                        <input name="find_id_payment" type="text" class="form-control" placeholder="123">
                    </div>
                    <div class="col-auto">
                        <button type="submit" class="btn btn-icon" aria-label="Button">
                            <!-- Download SVG icon from http://tabler-icons.io/i/search -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><circle cx="10" cy="10" r="7"></circle><line x1="21" y1="21" x2="15" y2="15"></line></svg>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="table-responsive">
    <table class="table card-table table-vcenter text-nowrap datatable">
        <thead>
        <tr>
            <th><?php echo e(__('ID')); ?></th>
            <th><?php echo e(__('Сумма')); ?></th>
            <?php if(Route::is('admin*')): ?>
                <th><?php echo e(__('Комиссия')); ?></th>
            <?php endif; ?>
            <th><?php echo e(__('Отправитель')); ?></th>
            <th><?php echo e(__('Получатель')); ?></th>
            <th><?php echo e(__('Дата')); ?></th>
        </tr>
        </thead>
        <tbody>

        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <strong><?php echo e($data->id); ?></strong>
                </td>
                <td>
                    <?php if(Route::is('admin*')): ?>
                        <strong class=""><?php echo e($data->amount); ?> руб.</strong>
                    <?php else: ?>
                        <?php if($data->from == Auth::user()->id): ?>
                            <strong class="text-danger">-<?php echo e($data->amount + $data->fee); ?> руб.</strong>
                        <?php else: ?>
                            <strong class="text-success">+<?php echo e($data->amount); ?> руб.</strong>
                        <?php endif; ?>
                    <?php endif; ?>

                </td>
                <?php if(Route::is('admin*')): ?>
                    <td>
                        <strong class="text-success">+<?php echo e($data->fee); ?> руб.</strong>
                    </td>
                <?php endif; ?>
                <td>
                    <strong><a><?php echo $data->from == Auth::user()->id ? '<span class="text-primary">Я</span>' : $data->from; ?></a></strong>
                </td>
                <td>
                    <strong><a><?php echo $data->to == Auth::user()->id ? '<span class="text-primary">Я</span>' : $data->to; ?></a></strong>
                </td>
                <td>
                    <strong class="text-muted"><?php echo e($data->created_at ? $data->created_at->format('d.m.Y H:i:s') : ''); ?></strong>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php if($payments->isEmpty()): ?>
        <p class="text-center mt-3 text-muted w-100"><strong class=""><?php echo e(__('Нет платежей')); ?></strong></p>

    <?php endif; ?>

</div>

<?php if(!$payments->isEmpty()): ?>
<div class="card-footer d-flex align-items-center">

    <div class="d-flex">
        <?php echo $payments->links(); ?>

    </div>

</div>

<?php endif; ?>

<script>
    let name_body_scroll_route = localStorage.getItem("body-scroll-name");
    if(name_body_scroll_route == null || name_body_scroll_route != "<?php echo e(Route::currentRouteName()); ?>"){
        localStorage.setItem("body-scroll-name", "<?php echo e(Route::currentRouteName()); ?>");
    } else {
        let body_scroll = localStorage.getItem("body-scroll");
        if (body_scroll !== null) {
            window.scrollTo({ top:body_scroll, left:0, behavior: "instant"});
        }
    }


    window.addEventListener('scroll', function() {
        console.log('scrolling');
        localStorage.setItem("body-scroll", window.scrollY);

    });
</script>
<?php /**PATH C:\OSPanel\domains\wallet\resources\views/includes/history.blade.php ENDPATH**/ ?>