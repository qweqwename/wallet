<?php $__env->startSection('title', 'Отправить деньги'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row row-cards justify-content-center">
        <div class="col-12 col-md-7 d-flex order-md-1  order-1">
            <div class="card w-100 active">
                <div class="card-header">
                    <div class="col">
                        <div class="card-title">
                            <?php echo e(__('Отправить деньги')); ?>

                        </div>
                    </div>
                </div>

                <form method="POST" action="<?php echo e(route('payment.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger small p-2">
                                <ul class="mb-0">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <?php echo e($message); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                            <div class="mb-3 mt-2">
                                <label class="form-label required mb-3"><?php echo e(__('Введите номер кошелька')); ?></label>
                                <input value="<?php echo e(request()->old('id')); ?>" autocomplete="off" type="text" class="form-control" name="id" placeholder="123456789">
                            </div>
                            <div class="mb-3">
                                <label class="form-label required mb-3"><?php echo e(__('Сумма платежа')); ?></label>
                                <input onload="inputAmountChanged(this.value)" onchange="inputAmountChanged(this.value)" oninput="inputAmountChanged(this.value)" value="<?php echo e(request()->old('amount')); ?>" autocomplete="off" type="text" class="form-control" id="inputAmount" name="amount" placeholder="100.45">
                            </div>

                        <div class="alert alert-primary py-2">Будет списано <strong><span id="amountWithFee">0</span> руб.</strong> с учетом комиссии <strong><span id="fee"><?php echo e($fee); ?></span>%</strong></div>

                    </div>
                    <div class="card-footer">
                        <div class="row align-items-center">
                            <button type="submit" class="btn btn-primary w-100">
                                Отправить
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>



        <div class="col-12 col-md-5 d-flex order-md-2  order-3">
            <div class="card w-100">
                <div class="card-header">
                    <div class="col">
                        <div class="card-title">
                            <?php echo e(__('Статистика за 30 дней')); ?>

                        </div>
                    </div>
                </div>
                <form action="">
                    <div class="card-body">
                        <canvas id="myChart" style="width:100%; height:100%;max-height: 300px"></canvas>
                    </div>
                </form>
            </div>
        </div>


        <div class="col-12 col-md-12 d-flex order-md-3  order-2 mb-4">
            <div class="card w-100">
                <div class="card-header">
                    <div class="col">
                        <div class="card-title">
                            <?php echo e(__('История платежей')); ?>

                        </div>
                    </div>
                </div>
                <?php echo $__env->make('includes.history', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <script>
            const ctx = document.getElementById('myChart').getContext('2d');
            const myChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ['Отправлено <?php echo e($stats->transfer); ?> руб.', 'Получено <?php echo e($stats->get); ?> руб.'],
                    datasets: [{
                        label: ' рублей',
                        data: [<?php echo e($stats->transfer); ?>, <?php echo e($stats->get); ?>],
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.2)',
                            'rgba(54, 162, 235, 0.2)',
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                        ],
                        borderWidth: 1
                    }]
                },

                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.label;
                                }
                            }
                        }
                    },
                    animation: {
                        duration: 0
                    },
                },
            });


            let fee = <?php echo e($fee); ?>;

            Number.prototype.toFixedNoRounding = function(n) {
                const reg = new RegExp("^-?\\d+(?:\\.\\d{0," + n + "})?", "g")
                const a = this.toString().match(reg)[0];
                const dot = a.indexOf(".");
                if (dot === -1) { // integer, insert decimal dot and pad up zeros
                    return a + "." + "0".repeat(n);
                }
                const b = n - (a.length - dot) + 1;
                return b > 0 ? (a + "0".repeat(b)) : a;
            }


            inputAmountChanged(document.querySelector('#inputAmount').value);
            function inputAmountChanged(value){
                if(value == null || value == ''){
                    value = '0';
                }

                try {
                    value = parseFloat(parseFloat(value.replace(',', '.')).toFixedNoRounding(2));
                    withFee = (value + (value / 100 * fee)).toFixedNoRounding(2);
                } catch (e){
                    withFee = (0.00).toFixedNoRounding(2);
                }

                document.querySelector('#amountWithFee').textContent = withFee;
                document.querySelector('#fee').textContent = fee;
            }
        </script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\wallet\resources\views/payment/transfer.blade.php ENDPATH**/ ?>