<?php /**PATH C:\OSPanel\domains\wallet\resources\views/register/settings.blade.php ENDPATH**/ ?>
