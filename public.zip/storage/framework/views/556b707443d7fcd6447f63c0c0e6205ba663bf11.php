

<?php echo $__env->make('home.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\OSPanel\domains\wallet\resources\views/home/settings.blade.php ENDPATH**/ ?>
