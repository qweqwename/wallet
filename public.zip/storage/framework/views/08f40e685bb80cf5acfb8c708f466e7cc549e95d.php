<div <?php echo e($attributes); ?> class="page-header d-print-none">
    <div class="container-xl">
        <div class="row g-2 align-items-center">
            <div class="col">
                <h2 class="page-title text-center w-100 d-block">
                    <?php echo e($slot); ?>

                </h2>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\OSPanel\domains\wallet\resources\views/components/page-header.blade.php ENDPATH**/ ?>