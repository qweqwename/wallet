<?php $__env->startSection('title', 'Изменить пароль'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.modal-alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row row-cards justify-content-center mb-3">
        <div class="col-12 col-md-6 float-none">
            <div class="card w-100 active">
                <div class="card-header">
                    <div class="col">
                        <div class="card-title">
                            <?php echo e(__('Изменить пароль')); ?>

                        </div>
                    </div>
                </div>
                <form method="POST" action="<?php echo e(route('user.update')); ?>">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="card-body">

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger small p-2">
                                <ul class="mb-0">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <?php echo e($message); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <div class="mb-3 mt-2">
                            <label class="form-label required mb-3"><?php echo e(__('Введите старый пароль')); ?></label>
                            <input autofocus autocomplete="off" type="password" class="form-control" name="old_password" placeholder="Lxf6NewWPe8f">
                        </div>
                        <div class="mb-3 mt-2">
                            <label class="form-label required mb-3"><?php echo e(__('Введите новый пароль')); ?></label>
                            <input autofocus autocomplete="off" type="password" class="form-control" name="new_password" placeholder="Lxf6NewWPe8f">
                        </div>
                        <div class="mb-1 mt-2">
                            <label class="form-label required mb-3"><?php echo e(__('Введите пароль еще раз')); ?></label>
                            <input autofocus autocomplete="off" type="password" class="form-control" name="confirm_password" placeholder="Lxf6NewWPe8f">
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="row align-items-center">
                            <button type="submit" class="btn btn-primary w-100">
                                Обновить пароль
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\wallet\resources\views/user/settings.blade.php ENDPATH**/ ?>